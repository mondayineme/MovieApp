package com.shaikhutech.videoplayer;

import android.view.View;

public interface CustomItemClickListner {
    void onItemClick(View v, int postion);
    void onItemLongClick(int position);

}
